package com.common;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class Common extends HttpServlet
{
	
	
	protected void checkstatusofinsertion(int getstatus,String name,HttpServletRequest req, HttpServletResponse response) throws ServletException, IOException 
	{
		PrintWriter out = response.getWriter();
		
		if(getstatus>0)
		{
			switch(name)
			{
				case "signup": response.sendRedirect("signin.jsp");
			}
		}	
		else
		{
			out.print("fail");
		}
	}
	
}
