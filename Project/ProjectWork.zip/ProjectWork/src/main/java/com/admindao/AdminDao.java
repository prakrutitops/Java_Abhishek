package com.admindao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.adminmodel.AdminContactModel;
import com.adminmodel.AdminLoginModel;
import com.dao.UserDao;
import com.model.SignupModel;

public class AdminDao 
{
	
	//Establish Connection
	
		public static Connection getconnect()
		{
			Connection con = null;
			
				try 
				{
					Class.forName("com.mysql.jdbc.Driver");
					con = DriverManager.getConnection("jdbc:mysql://localhost:3306/webwing","root","");
				} 
				catch (Exception e) 
				{
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
			
			return con;
		}
		
		//Login User
		
		public AdminLoginModel Login(AdminLoginModel model) 
		{
			
			AdminLoginModel obj = null;

			try {
				Connection con = UserDao.getconnect();
				PreparedStatement ps = con.prepareStatement("select * from adminlogin where username=? and password=?");
				ps.setString(1, model.getUsername());
				ps.setString(2, model.getPassword());

				ResultSet rs = ps.executeQuery();

				if (rs.next()) 
				{
					obj = new AdminLoginModel();
					obj.setId(rs.getInt("id"));
					obj.setUsername(rs.getString("username"));
					obj.setPassword(rs.getString("password"));
					
				}

			}
			catch (SQLException e) 
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			return obj;
		}
		
		//Admin Contact View
		public static List<AdminContactModel> adminconatctviewdata()
		{
			Connection con = AdminDao.getconnect();
			List<AdminContactModel>list = new ArrayList();
			
			String sql ="Select * from contacteduser";
			
			try 
			{
				PreparedStatement ps = con.prepareStatement(sql);
				
				ResultSet set = ps.executeQuery();
				
				while(set.next())
				{
					int id = set.getInt(1);
					String name = set.getString(2);
					String email = set.getString(3);
					String phone = set.getString(4);
					String message = set.getString(5);
					String status = set.getString(6);
					String remarks = set.getString(7);
					
					
					AdminContactModel m = new AdminContactModel();
					m.setId(id);
					m.setName(name);
					m.setEmail(email);
					m.setPhone(phone);
					m.setMessage(message);
					m.setStatus(status);
					m.setRemarks(remarks);
					list.add(m);
					
				}
				
				
			}
			catch (Exception e) 
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			return list;
			
		}
		
		
}
