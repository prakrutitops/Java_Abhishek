package com.admindao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.adminmodel.AdminLoginModel;
import com.dao.UserDao;
import com.model.SignupModel;

public class AdminDao 
{
	
	//Establish Connection
	
		public static Connection getconnect()
		{
			Connection con = null;
			
				try 
				{
					Class.forName("com.mysql.jdbc.Driver");
					con = DriverManager.getConnection("jdbc:mysql://localhost:3306/webwing","root","");
				} 
				catch (Exception e) 
				{
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
			
			return con;
		}
		
		//Login User
		
		public AdminLoginModel Login(AdminLoginModel model) 
		{
			
			AdminLoginModel obj = null;

			try {
				Connection con = UserDao.getconnect();
				PreparedStatement ps = con.prepareStatement("select * from adminlogin where username=? and password=?");
				ps.setString(1, model.getUsername());
				ps.setString(2, model.getPassword());

				ResultSet rs = ps.executeQuery();

				if (rs.next()) 
				{
					obj = new AdminLoginModel();
					obj.setId(rs.getInt("id"));
					obj.setUsername(rs.getString("username"));
					obj.setPassword(rs.getString("password"));
					
				}

			}
			catch (SQLException e) 
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			return obj;
		}
		
}
