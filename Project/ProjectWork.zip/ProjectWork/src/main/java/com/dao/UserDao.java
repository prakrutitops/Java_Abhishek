package com.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.model.ContactModel;
import com.model.SignupModel;

public class UserDao 
{
	
	//Establish Connection
	
	public static Connection getconnect()
	{
		Connection con = null;
		
			try 
			{
				Class.forName("com.mysql.jdbc.Driver");
				con = DriverManager.getConnection("jdbc:mysql://localhost:3306/webwing","root","");
			} 
			catch (Exception e) 
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		
		return con;
	}
	
	//Signup User
	
	public static int signupuser(SignupModel m)
	{
		int status = 0;
		
		Connection con = UserDao.getconnect();
		
		try 
		{
			String sql ="insert into users(fullname,email,phone,password) values (?,?,?,?)";
			PreparedStatement ps = con.prepareStatement(sql);
			
			ps.setString(1,m.getFullname());
			ps.setString(2,m.getEmail());
			ps.setString(3,m.getPhone());
			ps.setString(4,m.getPassword());
			
			status = ps.executeUpdate();
		} 
		catch (Exception e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return status;
	}
	
	//Login User
	
	public SignupModel Login(SignupModel model) 
	{
		
		SignupModel obj = null;

		try {
			Connection con = UserDao.getconnect();
			PreparedStatement ps = con.prepareStatement("select * from users where email=? and password=?");
			ps.setString(1, model.getEmail());
			ps.setString(2, model.getPassword());

			ResultSet rs = ps.executeQuery();

			if (rs.next()) 
			{
				obj = new SignupModel();
				obj.setId(rs.getInt("id"));
				obj.setFullname(rs.getString("fullname"));
				obj.setEmail(rs.getString("email"));
				obj.setPhone(rs.getString("phone"));
				obj.setPassword(rs.getString("password"));
				
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return obj;
	}
	

	//update 
	
	public static int updatedata(SignupModel m)
	{
		Connection con = UserDao.getconnect();
		
		int status = 0;
		
		String sql ="update users set fullname=?,phone=? where email=?";
		
		try 
		{
			PreparedStatement ps = con.prepareStatement(sql);
			
			//get all details from model
			
			ps.setString(1,m.getFullname());
			ps.setString(2,m.getPhone());
			ps.setString(3,m.getEmail());
			
			
			
			status = ps.executeUpdate();
			
		}
		catch (Exception e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		return status;
	}
	
	//Contact Insert User
	
		public static int contactinsertuser(ContactModel m)
		{
			int status = 0;
			
			Connection con = UserDao.getconnect();
			
			try 
			{
				String sql ="insert into contacteduser(name,email,phone,message,status,remarks) values (?,?,?,?,?,?)";
				PreparedStatement ps = con.prepareStatement(sql);
				
				ps.setString(1,m.getName());
				ps.setString(2,m.getEmail());
				ps.setString(3,m.getPhone());
				ps.setString(4,m.getMessage());
				ps.setString(5,"Pending");
				ps.setString(6,"New");
				
				status = ps.executeUpdate();
			} 
			catch (Exception e) 
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			return status;
		}
		
	
}
