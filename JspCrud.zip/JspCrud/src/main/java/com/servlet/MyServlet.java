package com.servlet;

public class MyServlet {

}
