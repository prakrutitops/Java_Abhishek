import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class Dao 
{
	
	//Connection Establish
	public static Connection getconnect()
	{
		Connection con = null;
		
		
		try 
		{
			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/test","root","");
		} 
		catch (Exception e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		return con;
	}
	
	
	//insert 
	
	public static int createdata(Model m)
	{
		Connection con = Dao.getconnect();
		
		int status = 0;
		
		String sql ="insert into info(fname,lname,mob,tech,fees) values (?,?,?,?,?)";
		
		try 
		{
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1,m.getFname());
			ps.setString(2,m.getLname());
			ps.setString(3,m.getMob());
			ps.setString(4,m.getTech());
			ps.setString(5,m.getFees());
			
			status = ps.executeUpdate();
			
		}
		catch (Exception e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		return status;
	}
	
		//view 
	
		public static List<Model> viewdata()
		{
			Connection con = Dao.getconnect();
			List<Model>list = new ArrayList();
			
			String sql ="Select * from info";
			
			try 
			{
				PreparedStatement ps = con.prepareStatement(sql);
				
				ResultSet set = ps.executeQuery();
				
				while(set.next())
				{
					int id = set.getInt(1);
					String fname = set.getString(2);
					String lname = set.getString(3);
					String mob = set.getString(4);
					String tech = set.getString(5);
					String fees = set.getString(6);
					
					Model m = new Model();
					m.setId(id);
					m.setFname(fname);
					m.setLname(lname);
					m.setMob(mob);
					m.setTech(tech);
					m.setFees(fees);
					
					list.add(m);
					
				}
				
				
			}
			catch (Exception e) 
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			return list;
			
		}
	
	
	
	
}
