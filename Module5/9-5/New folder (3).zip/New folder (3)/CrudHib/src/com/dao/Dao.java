package com.dao;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.model.Person;
import com.util.Util;

public class Dao 
{
	public void insert(Person p)
	{
		Session sess = new Util().getconnect();
		Transaction tr = sess.beginTransaction();
		sess.save(p);
		tr.commit();
		sess.close();
	}
}
