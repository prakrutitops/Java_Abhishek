package com.model;

public class Address {
private String add;

public String getAdd() {
	return add;
}

public void setAdd(String add) {
	this.add = add;
}

}
